import os
import sys

# Estensioni da includere
ESTENSIONI_VALIDE = {".txt", ".conllu", ".eaf"}

# Caratteri mal codificati da correggere
SOSTITUZIONI = {
    "Ã\x83Â¨": "è",
    "Ã\x83Â": "à",
    "Ã\x83Â¬": "ì",

}

def sostituisci_stringhe_nei_file(cartella):
    for root, _, files in os.walk(cartella):
        for filename in files:
            if any(filename.endswith(ext) for ext in ESTENSIONI_VALIDE):
                file_path = os.path.join(root, filename)

                try:
                    with open(file_path, "r", encoding="utf-8", errors="ignore") as file:
                        contenuto = file.read()

                    for vecchia, nuova in SOSTITUZIONI.items():
                        contenuto = contenuto.replace(vecchia, nuova)

                    with open(file_path, "w", encoding="utf-8") as file:
                        file.write(contenuto)

                    print(f"Corretto: {file_path}")
                except Exception as e:
                    print(f"Errore con {file_path}: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Uso: python3 ripara_caratteri.py <cartella>")
        sys.exit(1)

    cartella = sys.argv[1]

    if not os.path.isdir(cartella):
        print("Cartella non valida.")
        sys.exit(1)

    sostituisci_stringhe_nei_file(cartella)
