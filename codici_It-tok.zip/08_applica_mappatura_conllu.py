import os
import sys
import pandas as pd
import re

def trova_file_conllu_ricorsivi(cartella):
    conllu_files = []
    for root, dirs, files in os.walk(cartella):
        for file in files:
            if file.endswith(".conllu") or file.endswith(".conllup") or file.endswith(".conll"):
                conllu_files.append(os.path.join(root, file))
    return conllu_files

def sostituisci_con_mappatura(testo, mappatura):
    if testo is None:
        return testo
    nuovo_testo = testo
    for vecchio, nuovo in mappatura.items():
        # sostituzione con matching esatto, case sensitive
        pattern = re.compile(r'\b{}\b'.format(re.escape(vecchio)))
        nuovo_testo = pattern.sub(nuovo, nuovo_testo)
    return nuovo_testo

def processa_file_conllu(percorso_file, mappatura):
    righe_modificate = []
    modificato = False

    with open(percorso_file, 'r', encoding='latin1') as f:
        for linea in f:
            if linea.startswith("#") or linea.strip() == "":
                # righe di commento o vuote lasciale così
                righe_modificate.append(linea)
                continue

            colonne = linea.strip().split('\t')
            if len(colonne) < 10:
                # righe non standard (es. multiword tokens) le lasciamo invariati
                righe_modificate.append(linea)
                continue

            form = colonne[1]
            lemma = colonne[2]

            form_nuovo = sostituisci_con_mappatura(form, mappatura)
            lemma_nuovo = sostituisci_con_mappatura(lemma, mappatura)

            if form != form_nuovo or lemma != lemma_nuovo:
                modificato = True

            colonne[1] = form_nuovo
            colonne[2] = lemma_nuovo

            righe_modificate.append('\t'.join(colonne) + '\n')

    if modificato:
        with open(percorso_file, 'w', encoding='utf-8') as f_out:
            f_out.writelines(righe_modificate)
        print(f"Sostituzioni fatte in {percorso_file}")
    else:
        print(f"Nessuna sostituzione in {percorso_file}")

def main(excel_file, cartella_conllu):
    print(f"Leggo il file Excel: {excel_file}")
    df = pd.read_excel(excel_file, header=None, engine='openpyxl')
    df[0] = df[0].astype(str).str.strip()
    df[1] = df[1].astype(str).str.strip()
    mappatura = dict(zip(df[0], df[1]))
    print(f"Mappatura caricata con {len(mappatura)} elementi")

    files_conllu = trova_file_conllu_ricorsivi(cartella_conllu)
    print(f"Trovati {len(files_conllu)} file CoNLL-U")

    for percorso_file in files_conllu:
        print(f"Processo file: {percorso_file}")
        processa_file_conllu(percorso_file, mappatura)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Uso: python3 applica_mappatura_conllu.py <file_excel.xlsx> <cartella_conllu>")
        sys.exit(1)
    excel_file = sys.argv[1]
    cartella_conllu = sys.argv[2]
    main(excel_file, cartella_conllu)
