# Prima cella (in Colab, da eseguire da sola):
# !pip install yt-dlp

# Poi questa, sostituendo gli ID

import yt_dlp

# Lista di ID video TikTok da scaricare
video_ids = [
        "ID_VIDEO"

]

# template URL di TikTok
base_url = "https://www.tiktok.com/@username/video/"

# Configurazione per il download
ydl_opts = {
    'outtmpl': '%(id)s.%(ext)s',  # Salva con il nome del video ID
    'format': 'mp4',
}

# Scarica ogni video
with yt_dlp.YoutubeDL(ydl_opts) as ydl:
    for video_id in video_ids:
        video_url = f"{base_url}{video_id}"
        try:
            print(f"Scaricando {video_url}...")
            ydl.download([video_url])
        except Exception as e:
            print(f"Errore con {video_url}: {e}")

print("Download completato!")
