import os
import sys

def main():
    cartella_conllu = sys.argv[1] if len(sys.argv) > 1 else "."
    print(f"Scansiono la cartella e sottocartelle: {cartella_conllu}")

    forme_propn = set()

    for root, dirs, files in os.walk(cartella_conllu):
        for filename in files:
            if filename.endswith(".conllu"):
                percorso_file = os.path.join(root, filename)
                print(f"Leggo file: {percorso_file}")
                try:
                    with open(percorso_file, "r", encoding="utf-8", errors="ignore") as file:
                        for linea in file:
                            if linea.startswith("#") or linea.strip() == "":
                                continue
                            colonne = linea.strip().split("\t")
                            if len(colonne) >= 4 and colonne[3] == "PROPN":
                                forme_propn.add(colonne[1])
                                # print(f"  → PROPN trovato: {colonne[1]}")  # puoi decommentare per debug
                except Exception as e:
                    print(f"Errore durante la lettura del file {percorso_file}: {e}")

    forme_propn_ordinate = sorted(forme_propn)

    print(f"\nTrovate {len(forme_propn_ordinate)} forme con POS PROPN:")
    for forma in forme_propn_ordinate[:10]:
        print(" -", forma)

    percorso_output = os.path.join(cartella_conllu, "liste_propn.txt")
    with open(percorso_output, "w", encoding="utf-8") as output:
        for forma in forme_propn_ordinate:
            output.write(forma + "\n")

    print(f"\nLista completa salvata in: {percorso_output}")

if __name__ == "__main__":
    main()
