import os
import sys
import pandas as pd
import re

def trova_file_txt_ricorsivi(cartella):
    txt_files = []
    for root, dirs, files in os.walk(cartella):
        for file in files:
            if file.endswith(".txt"):
                txt_files.append(os.path.join(root, file))
    return txt_files

def main(excel_file, cartella_testi):
    print(f"Leggo il file Excel: {excel_file}")
    df = pd.read_excel(excel_file, header=None, engine='openpyxl')
    df[0] = df[0].astype(str).str.strip()
    df[1] = df[1].astype(str).str.strip()
    mappatura = dict(zip(df[0], df[1]))
    print(f"Mappatura caricata con {len(mappatura)} elementi")

    files_txt = trova_file_txt_ricorsivi(cartella_testi)
    print(f"Trovati {len(files_txt)} file .txt")

    for percorso_file in files_txt:
        print(f"Leggo file: {percorso_file}")
        with open(percorso_file, 'r', encoding='utf-8') as file:
            contenuto = file.read()

        contenuto_originale = contenuto
        for vecchio, nuovo in mappatura.items():
            pattern = re.compile(r'\b{}\b'.format(re.escape(vecchio)), flags=re.IGNORECASE)
            if pattern.search(contenuto):
                print(f"Trovata da sostituire '{vecchio}' in {percorso_file}")
            contenuto = pattern.sub(nuovo, contenuto)

        if contenuto != contenuto_originale:
            with open(percorso_file, 'w', encoding='utf-8') as file:
                file.write(contenuto)
            print(f"Sostituzioni fatte in {percorso_file}")
        else:
            print(f"Nessuna sostituzione in {percorso_file}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Uso: python3 applica_mappatura.py <file_excel.xlsx> <cartella_testi>")
        sys.exit(1)
    excel_file = sys.argv[1]
    cartella_testi = sys.argv[2]
    main(excel_file, cartella_testi)
