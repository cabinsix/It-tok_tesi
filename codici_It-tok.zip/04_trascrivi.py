# Installazione (in Colab, eseguire in questo ordine):
# !pip install openai-whisper pympi-ling ffmpeg-python
# !pip install --upgrade --force-reinstall torch
# !pip install --upgrade --force-reinstall openai-whisper
# !pip install openai-whisper pympi-ling ffmpeg-python

# Trascrive e crea i file .txt ed .eaf

import whisper
import ffmpeg
import os
import pympi  # Libreria per creare file EAF
from pathlib import Path
import glob

# Carica il modello Whisper (Large per massima precisione)
model = whisper.load_model("large")

def process_video(video_path):
    """ Estrae l'audio dal video, trascrive e salva un file .eaf per ELAN e un .txt con il testo. """
    video_path = Path(video_path)
    output_audio = video_path.with_suffix(".wav")
    output_eaf = video_path.with_suffix(".eaf")
    output_txt = video_path.with_suffix(".txt")

    print(f"Estrazione audio da {video_path.name}...")
    ffmpeg.input(str(video_path)).output(str(output_audio), acodec="pcm_s16le", ac=1, ar="16000").run(overwrite_output=True, quiet=True)

    print(f"Trascrizione di {video_path.name}...")
    result = model.transcribe(str(output_audio), word_timestamps=True)

    # Creazione file TXT
    print(f"Creazione file TXT per {video_path.name}...")
    with open(output_txt, "w", encoding="utf-8") as txt_file:
        for segment in result["segments"]:
            start_time = segment["start"]
            end_time = segment["end"]
            text = segment["text"]
            txt_file.write(f"[{start_time:.2f} - {end_time:.2f}] {text}\n")

    print(f"Creazione file ELAN per {video_path.name}...")
    eaf = pympi.Elan.Eaf()
    eaf.add_tier("Trascrizione")

    # Aggiungi ogni segmento con timestamp
    for segment in result["segments"]:
        start_time = int(segment["start"] * 1000)  # ELAN usa millisecondi
        end_time = int(segment["end"] * 1000)
        text = segment["text"]
        eaf.add_annotation("Trascrizione", start_time, end_time, text)

    # Salva il file .eaf
    eaf.to_file(str(output_eaf))

    print(f"Trascrizione completata! File ELAN salvato come {output_eaf}")
    print(f"Trascrizione completata! File TXT salvato come {output_txt}")

    # Rimuove il file audio temporaneo
    os.remove(output_audio)

def process_multiple_videos(video_list):
    """ Processa più video e crea un file .eaf e .txt per ciascuno. """
    for video in video_list:
        process_video(video)

def get_video_files_from_directory(directory):
    """ Ottieni tutti i file .mp4 in una cartella. """
    video_files = []
    for filename in os.listdir(directory):
        if filename.endswith(".mp4"):
            video_files.append(os.path.join(directory, filename))
    return video_files

# Sostituisci con il percorso della cartella contenente i video .mp4
video_directory = "."  # Percorso della cartella
video_files = get_video_files_from_directory(video_directory)

# Processa i video trovati nella cartella
process_multiple_videos(video_files)
