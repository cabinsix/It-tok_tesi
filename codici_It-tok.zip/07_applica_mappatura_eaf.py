import os
import sys
import pandas as pd
import xml.etree.ElementTree as ET
import re

def trova_file_eaf_ricorsivi(cartella):
    eaf_files = []
    for root, dirs, files in os.walk(cartella):
        for file in files:
            if file.endswith(".eaf"):
                eaf_files.append(os.path.join(root, file))
    return eaf_files

def sostituisci_testo_nel_testo(original_text, mappatura):
    if original_text is None:
        return original_text
    nuovo_testo = original_text
    for vecchio, nuovo in mappatura.items():
        pattern = re.compile(r'\b{}\b'.format(re.escape(vecchio)), flags=re.IGNORECASE)
        nuovo_testo = pattern.sub(nuovo, nuovo_testo)
    return nuovo_testo

def main(excel_file, cartella_eaf):
    print(f"Leggo il file Excel: {excel_file}")
    df = pd.read_excel(excel_file, header=None, engine='openpyxl')
    df[0] = df[0].astype(str).str.strip()
    df[1] = df[1].astype(str).str.strip()
    mappatura = dict(zip(df[0], df[1]))
    print(f"Mappatura caricata con {len(mappatura)} elementi")

    files_eaf = trova_file_eaf_ricorsivi(cartella_eaf)
    print(f"Trovati {len(files_eaf)} file .eaf")

    for percorso_file in files_eaf:
        print(f"Processo file: {percorso_file}")
        tree = ET.parse(percorso_file)
        root = tree.getroot()

        # ELAN store le annotazioni dentro TAG <ANNOTATION_VALUE> (di solito)
        modificato = False
        for annotation_value in root.iter('ANNOTATION_VALUE'):
            testo_vecchio = annotation_value.text
            testo_nuovo = sostituisci_testo_nel_testo(testo_vecchio, mappatura)
            if testo_nuovo != testo_vecchio:
                annotation_value.text = testo_nuovo
                modificato = True

        if modificato:
            tree.write(percorso_file, encoding='utf-8', xml_declaration=True)
            print(f"Sostituzioni fatte in {percorso_file}")
        else:
            print(f"Nessuna sostituzione necessaria in {percorso_file}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Uso: python3 applica_mappatura_eaf.py <file_excel.xlsx> <cartella_eaf>")
        sys.exit(1)
    excel_file = sys.argv[1]
    cartella_eaf = sys.argv[2]
    main(excel_file, cartella_eaf)
