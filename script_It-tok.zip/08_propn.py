"""08_propn.py - Supporto all'anonimizzazione: estrae i nomi propri dai CoNLL-U.

Passo 1 (estrai): elenca tutti i token PROPN con frequenza e file in cui
compaiono, in un CSV da completare a mano con la colonna "sostituto"
(lasciare vuoto per mantenere la forma, es. nomi di personaggi pubblici).
Passo 2 (applica): sostituisce FORM e LEMMA secondo il CSV compilato.

Uso:
  pip install conllu
  python 08_propn.py estrai  conllu/*.conllu --csv propn.csv
  python 08_propn.py applica conllu/*.conllu --csv propn.csv --out conllu_anon/
"""
import argparse
import csv
from collections import Counter, defaultdict
from pathlib import Path

from conllu import parse


def estrai(file, csv_out):
    freq, dove = Counter(), defaultdict(set)
    for f in file:
        for frase in parse(Path(f).read_text(encoding="utf-8")):
            for t in frase:
                if t["upos"] == "PROPN":
                    freq[t["form"]] += 1
                    dove[t["form"]].add(Path(f).stem)
    with open(csv_out, "w", newline="", encoding="utf-8") as h:
        w = csv.writer(h)
        w.writerow(["forma", "frequenza", "file", "sostituto"])
        for forma, n in freq.most_common():
            w.writerow([forma, n, " ".join(sorted(dove[forma])), ""])


def applica(file, csv_in, out):
    with open(csv_in, encoding="utf-8") as h:
        mappa = {r["forma"]: r["sostituto"] for r in csv.DictReader(h) if r["sostituto"]}
    Path(out).mkdir(parents=True, exist_ok=True)
    for f in file:
        frasi = parse(Path(f).read_text(encoding="utf-8"))
        for frase in frasi:
            for t in frase:
                if t["form"] in mappa:
                    t["form"] = t["lemma"] = mappa[t["form"]]
            frase.metadata.pop("text", None)        # il testo originale conterrebbe i nomi
        Path(out, Path(f).name).write_text(
            "".join(s.serialize() for s in frasi), encoding="utf-8")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("azione", choices=["estrai", "applica"])
    p.add_argument("file", nargs="+")
    p.add_argument("--csv", default="propn.csv")
    p.add_argument("--out", default="conllu_anon")
    a = p.parse_args()
    estrai(a.file, a.csv) if a.azione == "estrai" else applica(a.file, a.csv, a.out)


if __name__ == "__main__":
    main()
