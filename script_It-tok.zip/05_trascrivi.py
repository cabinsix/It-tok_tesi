# 05_trascrivi.py - Estrazione audio, trascrizione con Whisper, file .txt allineato e .eaf.
# Installazione (in Colab: anteporre "!" ai comandi):
#   pip install openai-whisper pympi-ling ffmpeg-python
#   # se Colab segnala conflitti con torch:
#   pip install --upgrade --force-reinstall torch
#   pip install --upgrade --force-reinstall openai-whisper
# Richiede ffmpeg installato nel sistema.

import os
from pathlib import Path

import ffmpeg
import pympi            # libreria per creare file EAF (ELAN)
import whisper

# Carica il modello Whisper (large, per la massima precisione)
model = whisper.load_model("large")


def process_video(video_path):
    """Estrae l'audio dal video, trascrive e salva un .eaf per ELAN e un .txt allineato."""
    video_path = Path(video_path)
    output_audio = video_path.with_suffix(".wav")
    output_eaf = video_path.with_suffix(".eaf")
    output_txt = video_path.with_suffix(".txt")

    # Audio mono, 16 kHz, PCM 16 bit: il formato su cui lavora Whisper
    ffmpeg.input(str(video_path)).output(
        str(output_audio), acodec="pcm_s16le", ac=1, ar="16000"
    ).run(overwrite_output=True, quiet=True)

    result = model.transcribe(str(output_audio), word_timestamps=True)

    # File TXT allineato: una riga per segmento, [inizio - fine] testo
    with open(output_txt, "w", encoding="utf-8") as txt_file:
        for segment in result["segments"]:
            txt_file.write(
                f"[{segment['start']:.2f} - {segment['end']:.2f}] {segment['text']}\n"
            )

    # File ELAN: un tier di trascrizione, tempi in millisecondi
    eaf = pympi.Elan.Eaf()
    eaf.add_tier("Trascrizione")
    for segment in result["segments"]:
        eaf.add_annotation("Trascrizione",
                           int(segment["start"] * 1000),
                           int(segment["end"] * 1000),
                           segment["text"])
    eaf.to_file(str(output_eaf))

    print(f"{video_path.name}: creati {output_txt.name} e {output_eaf.name}")
    os.remove(output_audio)          # rimuove il file audio temporaneo


def get_video_files_from_directory(directory):
    """Restituisce tutti i file .mp4 di una cartella."""
    return [os.path.join(directory, f) for f in os.listdir(directory) if f.endswith(".mp4")]


video_directory = "."    # cartella che contiene i video .mp4
for video in get_video_files_from_directory(video_directory):
    process_video(video)
