#!/usr/bin/env bash
# 02_query_gen.sh - Interrogazione per Gen, formato "risposta" (marzo 2025).
# La didascalia automatica "Risposta a @utente" viene intercettata
# con il campo keyword (ricerca nella descrizione del video).
# Prerequisito: source 00_token.sh

curl -L -X POST \
  "https://open.tiktokapis.com/v2/research/video/query/?fields=id,video_description,voice_to_text,username,create_time,video_duration" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -H "Content-Type: application/json" \
  --data-raw '{
    "query": {
      "and": [
        {"operation": "EQ", "field_name": "region_code", "field_values": ["IT"]}
      ],
      "or": [
        {"operation": "EQ", "field_name": "keyword", "field_values": ["risposta"]}
      ],
      "not": [
        {"operation": "EQ", "field_name": "video_length", "field_values": ["SHORT"]},
        {"operation": "EQ", "field_name": "video_length", "field_values": ["MID"]}
      ]
    },
    "start_date": "20250301",
    "end_date": "20250331",
    "max_count": 100,
    "is_random": true
  }' > oimar.json

# Per gli altri due formati si cambia solo il blocco "or":
#   stitch:    {"operation": "EQ", "field_name": "keyword",      "field_values": ["stitch"]}
#   storytime: {"operation": "EQ", "field_name": "hashtag_name", "field_values": ["storytiime"]}
