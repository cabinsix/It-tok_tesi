"""06_pulisci.py - Dalla trascrizione annotata al testo da passare a spaCy.

Rimuove:
  - i tempi di allineamento [0.00 - 4.84];
  - le sezioni escluse dall'analisi, con il loro contenuto:
    <CLIP>...</CLIP> (parlato tratto da altri video) e
    <OTHER_SP>...</OTHER_SP> (altri parlanti);
  - tutti gli altri tag CLIPS e It-tok, conservando il testo che racchiudono
    (es. <READ>...</READ>, [dialect]...[/dialect], <MASK_IL>...</MASK_IL>).

Uso:
  python 06_pulisci.py trascrizioni/*.antr.txt --out testo_pulito/
"""
import argparse
import re
from pathlib import Path

TEMPI = re.compile(r"\[\d+(?:\.\d+)?\s*-\s*\d+(?:\.\d+)?\]")
ESCLUSE = re.compile(r"<(CLIP|OTHER_SP)>.*?</\1>", flags=re.DOTALL)
TAG_ANGOLARI = re.compile(r"</?[^<>\s]+>")         # <sp> <ehm> <READ> </READ> ...
TAG_QUADRI = re.compile(r"\[/?[A-Za-z_]+\]")         # [dialect] [/foreign_word] ...


def pulisci(testo):
    testo = TEMPI.sub(" ", testo)
    testo = ESCLUSE.sub(" ", testo)                  # prima le sezioni intere
    testo = TAG_ANGOLARI.sub(" ", testo)
    testo = TAG_QUADRI.sub(" ", testo)
    return re.sub(r"\s+", " ", testo).strip()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("file", nargs="+")
    p.add_argument("--out", default="testo_pulito")
    a = p.parse_args()
    Path(a.out).mkdir(parents=True, exist_ok=True)
    for f in a.file:
        idv = Path(f).name.replace(".antr.txt", "")
        testo = pulisci(Path(f).read_text(encoding="utf-8"))
        Path(a.out, f"{idv}.txt").write_text(testo + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
