"""05b_derivati.py - File derivati per ciascun video, dopo la revisione manuale.

A partire dal .mp4 e dal .txt allineato già rivisto a mano produce:
  <ID>.mp3          traccia audio (l'unico materiale audiovisivo condivisibile)
  <ID>.txt          trascrizione ortografica continua, senza tempi
  <ID>.antr.txt     copia dell'allineata, da annotare a mano (CLIPS + tag It-tok)
L'allineata viene rinominata <ID>_aligned.txt.

Uso:
  python 05b_derivati.py 7445038266471976214 1024_S
  (primo argomento: ID TikTok; secondo: ID di corpus)
"""
import re
import shutil
import sys
from pathlib import Path

import ffmpeg

id_tiktok, id_corpus = sys.argv[1], sys.argv[2]
mp4, allineata = Path(f"{id_tiktok}.mp4"), Path(f"{id_tiktok}.txt")

ffmpeg.input(str(mp4)).output(f"{id_corpus}.mp3", acodec="libmp3lame",
                              audio_bitrate="192k").run(overwrite_output=True, quiet=True)

testo = allineata.read_text(encoding="utf-8")
shutil.copy(allineata, f"{id_corpus}_aligned.txt")
shutil.copy(allineata, f"{id_corpus}.antr.txt")
shutil.copy(mp4.with_suffix(".eaf"), f"{id_corpus}.eaf")

ortografica = re.sub(r"\[\d+\.\d+ - \d+\.\d+\]\s*", "", testo)
ortografica = re.sub(r"\s+", " ", ortografica).strip()
Path(f"{id_corpus}.txt").write_text(ortografica + "\n", encoding="utf-8")
print(f"{id_corpus}: mp3, txt, _aligned.txt, .antr.txt, .eaf")
