#!/usr/bin/env bash
# 00_token.sh - Genera un client access token per la Research API di TikTok.
# Il token vale 2 ore (expires_in = 7200): va rigenerato a ogni sessione.
# Uso:
#   export TIKTOK_CLIENT_KEY="..."      # dal portale "Research API" > progetto
#   export TIKTOK_CLIENT_SECRET="..."   # NON condividere, NON pubblicare
#   source 00_token.sh                  # imposta la variabile ACCESS_TOKEN

ACCESS_TOKEN=$(curl --silent --location --request POST \
  'https://open.tiktokapis.com/v2/oauth/token/' \
  --header 'Content-Type: application/x-www-form-urlencoded' \
  --header 'Cache-Control: no-cache' \
  --data-urlencode "client_key=${TIKTOK_CLIENT_KEY}" \
  --data-urlencode "client_secret=${TIKTOK_CLIENT_SECRET}" \
  --data-urlencode 'grant_type=client_credentials' \
  | jq -r '.access_token')

export ACCESS_TOKEN
echo "Token generato (inizia con: ${ACCESS_TOKEN:0:8}...)"
