"""07_spacy_conllu.py - Lemmatizzazione e PoS tagging con spaCy, output CoNLL-U.

Ogni video è un unico blocco (una sola "frase" CoNLL-U con sent_id = ID video):
la segmentazione in frasi si fa solo per la treebank, in Arborator.
Si scrivono FORM, LEMMA, UPOS e XPOS; FEATS, HEAD, DEPREL e DEPS restano "_"
(le dipendenze di Tr-It-tok sono annotate a mano da zero).

Uso:
  pip install "spacy>=3.8,<3.9"
  python -m spacy download it_core_news_lg
  python 07_spacy_conllu.py testo_pulito/*.txt --out conllu/

NB: i risultati dipendono dalla versione di spaCy e del modello. Il dato di
riferimento di It-tok sono i CoNLL-U corretti a mano, non l'output di questo script.
"""
import argparse
from pathlib import Path

import spacy


def doc_a_conllu(doc, sent_id):
    righe = [f"# sent_id = {sent_id}", f"# text = {doc.text}"]
    token = [t for t in doc if not t.is_space]
    for i, t in enumerate(token, start=1):
        misc = "_" if t.whitespace_ else "SpaceAfter=No"
        righe.append("\t".join([
            str(i), t.text, t.lemma_ or "_", t.pos_ or "_", t.tag_ or "_",
            "_", "_", "_", "_", misc,
        ]))
    return "\n".join(righe) + "\n\n"


def main():
    p = argparse.ArgumentParser()
    p.add_argument("file", nargs="+")
    p.add_argument("--modello", default="it_core_news_lg")
    p.add_argument("--out", default="conllu")
    a = p.parse_args()
    Path(a.out).mkdir(parents=True, exist_ok=True)

    nlp = spacy.load(a.modello)
    print("spaCy", spacy.__version__, "| modello", a.modello, nlp.meta["version"])
    for f in a.file:
        idv = Path(f).stem
        doc = nlp(Path(f).read_text(encoding="utf-8").strip())
        Path(a.out, f"{idv}.conllu").write_text(doc_a_conllu(doc, idv), encoding="utf-8")


if __name__ == "__main__":
    main()
