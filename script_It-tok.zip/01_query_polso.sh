#!/usr/bin/env bash
# 01_query_polso.sh - Interrogazione per PolSo (ottobre 2024).
# Video registrati in Italia, con almeno uno degli hashtag elencati,
# esclusi SHORT (<15 s) e MID (15-60 s), campione casuale di max 100 video.
# Prerequisito: source 00_token.sh

curl -L -X POST \
  "https://open.tiktokapis.com/v2/research/video/query/?fields=id,video_description,voice_to_text,username,create_time,video_duration" \
  -H "Authorization: Bearer ${ACCESS_TOKEN}" \
  -H "Content-Type: application/json" \
  --data-raw '{
    "query": {
      "and": [
        {"operation": "EQ", "field_name": "region_code", "field_values": ["IT"]}
      ],
      "or": [
        {"operation": "IN", "field_name": "hashtag_name",
         "field_values": ["abilismo", "aborto", "omofobia", "transfobia",
           "omolesbobitransfobia", "misoginia", "metoo", "specismo",
           "antispecismo", "feminist", "IVG", "overtourism", "ecoansia",
           "ecologismo", "antirazzista", "antifascista", "ecoterrorismo",
           "anticapitalismo", "ecofemminismo", "intersezionale", "privilegio",
           "grassofobia", "femminismointersezionale", "dirittiLGBT"]}
      ],
      "not": [
        {"operation": "EQ", "field_name": "video_length", "field_values": ["SHORT"]},
        {"operation": "EQ", "field_name": "video_length", "field_values": ["MID"]}
      ]
    },
    "start_date": "20241001",
    "end_date": "20241031",
    "max_count": 100,
    "is_random": true
  }' > ITT_PolSo_1024_7.json
