# 04_scarica.py - Download dei video idonei a partire dall'ID (yt-dlp).
# Installazione:  pip install yt-dlp
#
# Nell'URL non serve il nome utente reale: TikTok risolve il video dal solo ID,
# quindi si usa il segnaposto "@username". Gli ID si copiano da idonei.json.

import yt_dlp

# Lista di ID video TikTok da scaricare
video_ids = [
    "7445038266471976214",
    # ...
]

# Template URL di TikTok
base_url = "https://www.tiktok.com/@username/video/"

# Configurazione per il download
ydl_opts = {
    "outtmpl": "%(id)s.%(ext)s",   # salva con il nome del video ID
    "format": "mp4",
}

# Scarica ogni video
with yt_dlp.YoutubeDL(ydl_opts) as ydl:
    for video_id in video_ids:
        video_url = f"{base_url}{video_id}"
        try:
            print(f"Scaricando {video_url}...")
            ydl.download([video_url])
        except Exception as e:
            print(f"Errore con {video_url}: {e}")

print("Download completato!")
