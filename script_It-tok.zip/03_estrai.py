"""03_estrai.py - Estrazione automatizzata, mese per mese, con la Research API.

Ripete l'interrogazione casuale (is_random=true) finché non si raggiunge il
numero desiderato di video idonei (con trascrizione automatica VTT e durata
> 60 s) o il numero massimo di chiamate. Ogni risposta grezza viene salvata
in JSON, così la raccolta resta documentata e ripetibile.

Uso:
  export TIKTOK_CLIENT_KEY=...  TIKTOK_CLIENT_SECRET=...
  python 03_estrai.py --sezione PolSo --mese 2024-10 --obiettivo 15
  python 03_estrai.py --sezione Gen --formato risposta --mese 2025-01
"""
import argparse
import calendar
import json
import os
import time
from pathlib import Path

import requests

URL_TOKEN = "https://open.tiktokapis.com/v2/oauth/token/"
URL_QUERY = "https://open.tiktokapis.com/v2/research/video/query/"
CAMPI = "id,video_description,voice_to_text,username,create_time,video_duration"

HASHTAG_POLSO = [
    "abilismo", "aborto", "omofobia", "transfobia", "omolesbobitransfobia",
    "misoginia", "metoo", "specismo", "antispecismo", "feminist", "IVG",
    "overtourism", "ecoansia", "ecologismo", "antirazzista", "antifascista",
    "ecoterrorismo", "anticapitalismo", "ecofemminismo", "intersezionale",
    "privilegio", "grassofobia", "femminismointersezionale", "dirittiLGBT",
]

# Condizione "or" per ciascun formato di Gen
FORMATI_GEN = {
    "risposta": {"operation": "EQ", "field_name": "keyword", "field_values": ["risposta"]},
    "stitch": {"operation": "EQ", "field_name": "keyword", "field_values": ["stitch"]},
    "storytime": {"operation": "EQ", "field_name": "hashtag_name", "field_values": ["storytiime"]},
}


class Token:
    """Client access token, rigenerato automaticamente prima della scadenza (2 h)."""

    def __init__(self):
        self.valore, self.creato = None, 0.0

    def get(self):
        if self.valore is None or time.time() - self.creato > 110 * 60:
            r = requests.post(
                URL_TOKEN,
                headers={"Content-Type": "application/x-www-form-urlencoded",
                         "Cache-Control": "no-cache"},
                data={"client_key": os.environ["TIKTOK_CLIENT_KEY"],
                      "client_secret": os.environ["TIKTOK_CLIENT_SECRET"],
                      "grant_type": "client_credentials"},
                timeout=30,
            )
            r.raise_for_status()
            self.valore, self.creato = r.json()["access_token"], time.time()
        return self.valore


def costruisci_query(sezione, formato):
    if sezione == "PolSo":
        condizione_or = {"operation": "IN", "field_name": "hashtag_name",
                         "field_values": HASHTAG_POLSO}
    else:
        condizione_or = FORMATI_GEN[formato]
    return {
        "and": [{"operation": "EQ", "field_name": "region_code", "field_values": ["IT"]}],
        "or": [condizione_or],
        "not": [
            {"operation": "EQ", "field_name": "video_length", "field_values": ["SHORT"]},
            {"operation": "EQ", "field_name": "video_length", "field_values": ["MID"]},
        ],
    }


def idoneo(video):
    """Criterio di idoneità: trascrizione automatica presente e durata > 60 s."""
    vtt = (video.get("voice_to_text") or "").strip()
    return bool(vtt) and (video.get("video_duration") or 0) > 60


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--sezione", choices=["PolSo", "Gen"], required=True)
    p.add_argument("--formato", choices=list(FORMATI_GEN), default="risposta")
    p.add_argument("--mese", required=True, help="AAAA-MM, es. 2024-10")
    p.add_argument("--obiettivo", type=int, default=15)
    p.add_argument("--max-chiamate", type=int, default=20)
    p.add_argument("--out", default="estrazioni")
    a = p.parse_args()

    anno, mese = map(int, a.mese.split("-"))
    # end_date può distare al massimo 30 giorni da start_date:
    # dal giorno 1 all'ultimo giorno del mese il vincolo è sempre rispettato.
    ultimo = calendar.monthrange(anno, mese)[1]
    start, end = f"{anno}{mese:02d}01", f"{anno}{mese:02d}{ultimo}"

    etichetta = a.sezione if a.sezione == "PolSo" else f"Gen-{a.formato}"
    cartella = Path(a.out) / etichetta / a.mese
    cartella.mkdir(parents=True, exist_ok=True)

    token, visti, idonei = Token(), {}, {}
    for n in range(1, a.max_chiamate + 1):
        corpo = {"query": costruisci_query(a.sezione, a.formato),
                 "start_date": start, "end_date": end,
                 "max_count": 100, "is_random": True}
        r = requests.post(f"{URL_QUERY}?fields={CAMPI}",
                          headers={"Authorization": f"Bearer {token.get()}",
                                   "Content-Type": "application/json"},
                          json=corpo, timeout=120)
        dati = r.json()
        (cartella / f"risposta_{n:03d}.json").write_text(
            json.dumps(dati, ensure_ascii=False, indent=2), encoding="utf-8")

        if dati.get("error", {}).get("code") != "ok":
            print("Errore:", dati.get("error"))
            time.sleep(10)
            continue

        for v in dati["data"].get("videos", []):
            vid = str(v.get("id") or v.get("video_id"))
            visti[vid] = v
            if idoneo(v):
                idonei[vid] = v
        print(f"[{n}] estratti unici: {len(visti)}  idonei: {len(idonei)}")
        if len(idonei) >= a.obiettivo:
            break
        time.sleep(2)

    (cartella / "idonei.json").write_text(
        json.dumps(list(idonei.values()), ensure_ascii=False, indent=2), encoding="utf-8")
    perc = 100 * len(idonei) / max(len(visti), 1)
    print(f"Fine: {len(visti)} video estratti, {len(idonei)} idonei ({perc:.0f}%)")


if __name__ == "__main__":
    main()
